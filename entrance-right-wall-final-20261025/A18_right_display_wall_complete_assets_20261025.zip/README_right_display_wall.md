# A18 right foreground display wall / 2026-10-25
Design: source is the user's 546x483 approved_entrance_trial.jpg; no scene redrawn.
Delivered source PNGs:
- entrance_bg_without_right_display_wall.png : concealed underlay, always drawn behind the wall; the exposed underlay is NOT itself a finished standalone room.
- entrance_fg_right_display_wall.png : independently transparent original wall and ornate frame.
- entrance_photo03_aperture_mask.png : precise photo opening as in current renderer.
- entrance_photo03_empty_backing.png : source-matching empty artwork appearance.
Display order: underlay -> avatar (when behind) -> artwork/empty backing -> foreground wall -> avatar (when in front) -> UI.
Pixel QA: original source == underlay+empty+wall at 546x483, with zero altered pixels.
Sample 3-photo QA differs at exactly 12 pixels because the foreground railing correctly occludes a small part of the upper-right photo. All other pixels match.
Official sprites are PNG source files, unmodified, no generated characters.
Game code untouched; still needs integration into actual collision and layers.
Plant separation and Level 2-6 decoration remain later work.
Visual art is a completed candidate for the right wall only; user approval still pending.
