# -*- coding: utf-8 -*-
"""A18 right-front gallery partition: production-compositable split material.
Exact approved source 546x483; no invented sprites or restyling.
Deliver UNDERLAY (cleaned), FOREGROUND (wall/frame), PHOTO_03 opening mask/backing;
independent foreground ordering QA including actual official sprites.
"""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter
import numpy as np, cv2, json,hashlib,zipfile
ROOT=Path(r"G:\マイドライブ\06.アプリ開発\03.開発・テスト\A18_パズル美術館")
R=Path(r"C:\Users\User\source\repos\a18-totteoki-museum-pages\entrance-test-v3\layout-test\assets\entrance\v0.3")
A=ROOT/"27_エントランス完成素材_右展示壁_v01"
PHOTO=ROOT/"25_エントランス個別素材制作_v01"/"QA_3photos_in_original_entrance.png"
SPRITES=ROOT/"00_正式採用素材"/"characters"
ref=R/"approved_entrance_trial.jpg"
for p in [ref,PHOTO,SPRITES/"curator-front-00.png",SPRITES/"butler-front-00.png"]:
    if not p.is_file(): raise FileNotFoundError(p)
src=Image.open(ref).convert("RGB")
orig=np.array(src)
H,W=orig.shape[:2]
assert (W,H)==(546,483)

# Deliberately contiguous foreground structure: sloping top trim, photo wall,
# panel, base moulding. Geometry traced against grid-overlay of actual approved JPG.
# Upper bounding top: (395,144)->(534,184); lower sloping edge
# (393,330)->(545,425), preserving the sloping plinth while avoiding the main carpet.
outline=[(394,147),(401,142),(406,143),(531,183),(538,189),
         (538,217),(545,218),(545,425),(532,421),
         (393,330),(393,184)]
m_wall=np.zeros((H,W),np.uint8)
cv2.fillPoly(m_wall,[np.array(outline,np.int32)],255)

# A photo itself must remain transparent. Preserve gold frame pixels OUTSIDE opening.
m_photo=np.zeros((H,W),np.uint8)
photo_quad=np.array([(426,201),(489,226),(489,323),(426,276)],np.int32)
cv2.fillConvexPoly(m_photo,photo_quad,255)
if (m_wall[m_photo>0]==0).any():
    raise AssertionError("Photo opening outside foreground")
m_frame=np.where(m_photo>0,0,m_wall).astype(np.uint8)
# Exposed backing through photo window when artwork is not yet registered.
def rgba_from_original(alpha):
    data=np.dstack([orig,alpha])
    return Image.fromarray(data,"RGBA")
fg=rgba_from_original(m_frame)
fg.save(A/"entrance_fg_right_display_wall.png",optimize=True)
mat=rgba_from_original(m_photo)
mat.save(A/"entrance_photo03_empty_backing.png",optimize=True)
wimg=Image.fromarray(np.dstack([np.full((H,W,3),255,np.uint8),m_photo]),"RGBA")
wimg.save(A/"entrance_photo03_aperture_mask.png",optimize=True)

# Underlay replacing the wall. Its continuity only matters where an avatar may
# be behind the wall. Scene is never shown without its foreground on top.
# Perceived corridor/floor layer is extended from adjacent architecture.
# Use Telea inpainting at 3x for soft image-space continuity, no generated objects.
mask_for_base=m_wall.copy()
# Restore hidden building with two real texture donors from the SAME room:
# a right-hand walnut wainscot fragment and a lower-right marble floor tile.
# This avoids any invented red carpet cone behind the foreground partition.
bg=orig.copy()
walnut=src.crop((334,146,390,213)).resize((W-393,210-142),Image.Resampling.BICUBIC)
marble=src.crop((390,401,473,481)).resize((W-393,H-210),Image.Resampling.BICUBIC)
replacement=np.zeros_like(bg)
replacement[142:210,393:W]=np.array(walnut)
replacement[210:H,393:W]=np.array(marble)
# Repaired pixels will only be revealed where an object is behind the wall;
# never invent or modify the visible parts of approved architecture.
bg[m_wall>0]=replacement[m_wall>0]
# Exact original outside wall. This is essential for no collateral damage.
bg[m_wall==0]=orig[m_wall==0]
base=Image.fromarray(bg,"RGB")
base.save(A/"entrance_bg_without_right_display_wall.png",optimize=True)

def composite(lower,*layers):
    under=lower.convert("RGBA").copy()
    for item in layers:under.alpha_composite(item)
    return under.convert("RGB")
# Full 1:1 visual reconstruction, original blank panel remains its correct color.
recon=composite(base,mat,fg)
recon.save(A/"QA_right_wall_reassembled_empty.png",optimize=True)
diff=np.abs(np.asarray(recon).astype(np.int16)-orig.astype(np.int16))
assert np.max(diff)==0 and np.count_nonzero(diff)==0,("not pixel exact",diff.max())
# Place pre-existing warped/photo-mapped sample INSIDE gallery opening.
photoImg=Image.open(PHOTO).convert("RGB")
photoSource=np.array(photoImg)
photoLayer=Image.fromarray(np.dstack([photoSource,m_photo]),"RGBA")
photoLayer.save(A/"QA_photo03_in_aperture.png",optimize=True)
photoComposite=composite(base,photoLayer,fg)
photoComposite.save(A/"QA_right_wall_with_photo03.png",optimize=True)
assert np.array_equal(np.asarray(photoComposite)[m_wall==0],orig[m_wall==0])
# Detect that photo wall itself (frame gold pixels) is pixel-exact.
assert np.array_equal(np.asarray(photoComposite)[m_frame>0],orig[m_frame>0])
def sprite(image,name,center,foot,width):
    im=Image.open(SPRITES/name).convert("RGBA")
    height=round(im.height*width/im.width)
    im=im.resize((width,height),Image.Resampling.NEAREST)
    image.alpha_composite(im,(round(center-width/2),round(foot-height)))
    return hashlib.sha256((SPRITES/name).read_bytes()).hexdigest()
# QA occlusion: character stands partially behind right-hand wall, while second
# version stands in front. Both use original approved pixel sprites.
under=base.convert("RGBA")
sprite(under,"curator-front-00.png",397,318,35)
under.alpha_composite(photoLayer);under.alpha_composite(fg)
under.convert("RGB").save(A/"QA_avatar_behind_right_wall.png",optimize=True)
over=base.convert("RGBA")
over.alpha_composite(photoLayer);over.alpha_composite(fg)
sprite(over,"curator-front-00.png",397,318,35)
over.convert("RGB").save(A/"QA_avatar_in_front_right_wall.png",optimize=True)
scene=base.convert("RGBA")
sprite(scene,"butler-front-00.png",140,371,43)
sprite(scene,"curator-front-00.png",287,366,35)
scene.alpha_composite(photoLayer);scene.alpha_composite(fg)
scene.convert("RGB").save(A/"QA_right_wall_formal_characters_and_photo.png",optimize=True)
# Side by side at 1x source resolution.
board=Image.new("RGB",(W*2,H))
board.paste(under.convert("RGB"),(0,0));board.paste(over.convert("RGB"),(W,0))
board.save(A/"QA_sprite_front_back_comparison.png",optimize=True)
# QA near the wall, zoom without changing pixel colors.
region=photoComposite.crop((385,140,546,408))
region.resize((483,804),Image.Resampling.NEAREST).save(A/"QA_right_wall_3x.png",optimize=True)
# Render study for when wall is suppressed. This is NOT the actual playable scene.
base.save(A/"QA_only_underlay_wall_removed.png",optimize=True)

qa={
 "approved_source":str(ref),"approved_hash":hashlib.sha256(ref.read_bytes()).hexdigest(),
 "canvas":[W,H],"foreground_outline":outline,"photo03_quad":photo_quad.tolist(),
 "foreground_pixel_area":int((m_frame>0).sum()),
 "photo_window_pixel_area":int((m_photo>0).sum()),
 "reassembled_matches_original":True,
 "rest_of_scene_unchanged":True,
 "sprite_source":"Original formal sprite PNG via nearest resize, no redraw",
 "still_game_integration":False,
 "status":"candidate_to_be_visually_reviewed",
 "files":{}
}
for f in A.glob("*.png"):
    im=Image.open(f)
    qa["files"][f.name]={"size":im.size,"mode":im.mode,"sha256":hashlib.sha256(f.read_bytes()).hexdigest()}
(A/"QA_manifest.json").write_text(json.dumps(qa,ensure_ascii=False,indent=2,default=list),encoding="utf-8")
print("PASS",qa["reassembled_matches_original"],"FRAME_PIXELS",qa["foreground_pixel_area"],"WINDOW_PIXELS",qa["photo_window_pixel_area"])
print("FILES",len(qa["files"]))
