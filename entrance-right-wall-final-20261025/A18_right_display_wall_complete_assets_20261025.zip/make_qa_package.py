# -*- coding: utf-8 -*-
from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np,hashlib,json,zipfile
ROOT=Path(r"G:\マイドライブ\06.アプリ開発\03.開発・テスト\A18_パズル美術館")
OUT=ROOT/"27_エントランス完成素材_右展示壁_v01"
CHAR=ROOT/"00_正式採用素材"/"characters"
source=Path(r"C:\Users\User\source\repos\a18-totteoki-museum-pages\entrance-test-v3\layout-test\assets\entrance\v0.3\approved_entrance_trial.jpg")
samples=ROOT/"25_エントランス個別素材制作_v01"/"QA_3photos_in_original_entrance.png"
base=Image.open(OUT/"entrance_bg_without_right_display_wall.png").convert("RGBA")
fg=Image.open(OUT/"entrance_fg_right_display_wall.png").convert("RGBA")
src=Image.open(source).convert("RGB")
photos=Image.open(samples).convert("RGB")
mask=Image.open(OUT/"entrance_photo03_aperture_mask.png").getchannel("A")
m12=Image.new("L",(546,483),0)
d=ImageDraw.Draw(m12)
d.rectangle((84,61,193,143),fill=255)
d.rectangle((373,61,459,143),fill=255)
leftBack=photos.convert("RGBA")
leftBack.putalpha(m12)
right=photos.convert("RGBA")
right.putalpha(mask)
mat=Image.open(OUT/"entrance_photo03_empty_backing.png").convert("RGBA")
def add_char(im,name,cx,foot,width):
    sprite=Image.open(CHAR/name).convert("RGBA")
    h=round(sprite.height*width/sprite.width)
    sprite=sprite.resize((width,h),Image.Resampling.NEAREST)
    im.alpha_composite(sprite,(int(cx-width//2),int(foot-h)))
def composite(withphoto=True,chars=True):
    im=base.copy()
    im.alpha_composite(leftBack)
    im.alpha_composite(right if withphoto else mat)
    im.alpha_composite(fg)
    if chars:
        add_char(im,"butler-front-00.png",139,370,43)
        add_char(im,"curator-front-00.png",285,371,35)
    return im.convert("RGB")
composite().save(OUT/"QA_complete_wall_three_photos_and_formal_sprites.png",optimize=True)
composite(withphoto=False).save(OUT/"QA_complete_wall_empty_slot_formal_sprites.png",optimize=True)
nochar=composite(withphoto=True,chars=False)
delta=np.abs(np.asarray(nochar).astype(np.int16)-np.asarray(photos).astype(np.int16))
bad=np.any(delta!=0,axis=2)
ys,xs=np.where(bad)
overlap=(np.asarray(m12)>0)&(np.asarray(fg.getchannel("A"))>0)
print('DIFF_PIXELS',int(bad.sum()),'MAX',int(delta.max()),'BBOX',(int(xs.min()),int(ys.min()),int(xs.max()),int(ys.max())) if len(xs) else None)
# Earlier photo prototype incorrectly drew the upper-right back-wall photograph
# OVER 12 physical foreground railing pixels. This new foreground correctly
# occludes that tiny overlap. Any other difference would be a regression.
assert int(bad.sum())==12 and np.all(~bad|overlap), "Unexpected photo compositing regression"
corrected=np.asarray(photos).copy()
corrected[overlap]=np.asarray(src)[overlap]
assert np.array_equal(np.asarray(nochar),corrected), "Layer order differs from physically correct target"
assert np.array_equal(np.asarray(src),np.asarray(Image.open(OUT/"QA_right_wall_reassembled_empty.png").convert("RGB")))
board=Image.new("RGB",(1092,483))
board.paste(src,(0,0));board.paste(Image.open(OUT/"QA_right_wall_reassembled_empty.png").convert("RGB"),(546,0))
board.save(OUT/"QA_original_vs_reassembly_exact.png",optimize=True)
checker=Image.new("RGB",(546,483),(228,224,215))
draw=ImageDraw.Draw(checker)
for y in range(0,483,16):
    for x in range(0,546,16):
        if ((x//16)+(y//16))%2==0:
            draw.rectangle((x,y,x+15,y+15),fill=(203,200,192))
tmp=checker.convert("RGBA")
tmp.alpha_composite(fg)
tmp.convert("RGB").save(OUT/"QA_independent_foreground_checker.png",optimize=True)
readme=OUT/"README_right_display_wall.md"
readme.write_text("""# A18 right foreground display wall / 2026-10-25
Design: source is the user's 546x483 approved_entrance_trial.jpg; no scene redrawn.
Delivered source PNGs:
- entrance_bg_without_right_display_wall.png : concealed underlay, always drawn behind the wall; the exposed underlay is NOT itself a finished standalone room.
- entrance_fg_right_display_wall.png : independently transparent original wall and ornate frame.
- entrance_photo03_aperture_mask.png : precise photo opening as in current renderer.
- entrance_photo03_empty_backing.png : source-matching empty artwork appearance.
Display order: underlay -> avatar (when behind) -> artwork/empty backing -> foreground wall -> avatar (when in front) -> UI.
Pixel QA: original source == underlay+empty+wall at 546x483, with zero altered pixels.
Sample 3-photo QA differs at exactly 12 pixels because the foreground railing correctly occludes a small part of the upper-right photo. All other pixels match.
Official sprites are PNG source files, unmodified, no generated characters.
Game code untouched; still needs integration into actual collision and layers.
Plant separation and Level 2-6 decoration remain later work.
Visual art is a completed candidate for the right wall only; user approval still pending.
""",encoding="utf-8")
package=[
"entrance_bg_without_right_display_wall.png",
"entrance_fg_right_display_wall.png",
"entrance_photo03_aperture_mask.png",
"entrance_photo03_empty_backing.png",
"QA_right_wall_reassembled_empty.png",
"QA_complete_wall_three_photos_and_formal_sprites.png",
"QA_complete_wall_empty_slot_formal_sprites.png",
"QA_original_vs_reassembly_exact.png",
"QA_sprite_front_back_comparison.png",
"QA_right_wall_3x.png",
"QA_independent_foreground_checker.png",
"build_right_wall.py","make_qa_package.py",readme.name
]
qa={"source_sha256":hashlib.sha256(source.read_bytes()).hexdigest(),
"full_photo_composite_exact_except_occlusion":True,
"photo_max_delta":int(delta.max()),
"photo_occlusion_corrected_pixels":int(bad.sum()),
"original_reassembly_exact":True,
"package_files":package,
"status":"RIGHT_WALL_COMPLETED_CANDIDATE_AWAITING_USER_APPROVAL_AND_GAME_INTEGRATION"}
manifest=OUT/"QA_final_report.json"
manifest.write_text(json.dumps(qa,ensure_ascii=False,indent=2),encoding="utf-8")
package.append(manifest.name)
zip_file=OUT/"A18_right_display_wall_complete_assets_20261025.zip"
with zipfile.ZipFile(zip_file,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name in package:
        p=OUT/name
        assert p.exists(),name
        z.write(p,arcname=name)
with zipfile.ZipFile(zip_file) as z:assert z.testzip() is None
print("QA",qa)
print("ZIP",str(zip_file),zip_file.stat().st_size)
